import pytest
import sdl2
from sdl2 import SDL_Init, SDL_Quit, SDL_INIT_VIDEO


@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_LoadLibrary(with_sdl):
    pass

@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_GetVkGetInstanceProcAddr(with_sdl):
    pass

@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_UnloadLibrary(with_sdl):
    pass

@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_GetInstanceExtensions(with_sdl):
    pass

@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_CreateSurface(with_sdl):
    pass

@pytest.mark.skip("not implemented")
def test_SDL_Vulkan_GetDrawableSize(with_sdl):
    pass
